# excel-runner

Run Http requests list in excel sheet



## how to use

```shell
pip install ex
```


| name      | method | url                                                                | data                        | headers                                         | verify                                                         | result |
| --------- | ------ | ------------------------------------------------------------------ | --------------------------- | ----------------------------------------------- | -------------------------------------------------------------- | ------ |
| get请求     | get    | [https://httpbin.org/get?a=1&b=2](https://httpbin.org/get?a=1&b=2) |                             |                                                 | res.status_code==200                                           |        |
| post-form | post   | [https://httpbin.org/post](https://httpbin.org/post)               | name=Kevin&age=1            | Content-Type: application/x-www-form-urlencoded | res.status_code==200  <br>res.json()['form']['name']=='Kevin'] |        |
| post-json | post   | [https://httpbin.org/post](https://httpbin.org/post)               | {"name": "Kevin", "age": 1} | Content-Type: application/json                  |                                                                |        |
| post-xml  | post   | [https://httpbin.org/post](https://httpbin.org/post)               | <xml>hello</xml>            | Content-Type: application/xml                   | result.json()["data"]=="<xml>hello</xml>"                      |        |
