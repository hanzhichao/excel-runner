from excel_runner import run_excel


def test_excel_runner():
    run_excel("testdata/data.xlsx")